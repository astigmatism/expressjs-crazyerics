#ifndef QB_CONFIG_H__
#define QB_CONFIG_H__

#define PACKAGE_NAME "retroarch"
#define HAVE_RGUI 1
/* #undef HAVE_ALSA */
/* #undef HAVE_OSS */
/* #undef HAVE_OSS_BSD */
#define HAVE_OSS_LIB 1
/* #undef HAVE_AL */
/* #undef HAVE_RSOUND */
/* #undef HAVE_ROAR */
/* #undef HAVE_JACK */
/* #undef HAVE_COREAUDIO */
/* #undef HAVE_PULSE */
/* #undef HAVE_SDL */
#define HAVE_OPENGL 1
/* #undef HAVE_GLES */
#define HAVE_VG 1
#define HAVE_EGL 1
/* #undef HAVE_KMS */
/* #undef HAVE_GBM */
/* #undef HAVE_DRM */
#define HAVE_DYLIB 1
#define HAVE_GETOPT_LONG 1
#define HAVE_THREADS 1
/* #undef HAVE_CG */
/* #undef HAVE_LIBXML2 */
/* #undef HAVE_SDL_IMAGE */
/* #undef HAVE_ZLIB */
#define HAVE_DYNAMIC 1
/* #undef HAVE_AVCODEC */
/* #undef HAVE_AVFORMAT */
/* #undef HAVE_AVUTIL */
/* #undef HAVE_SWSCALE */
/* #undef HAVE_FREETYPE */
/* #undef HAVE_XVIDEO */
/* #undef HAVE_X11 */
/* #undef HAVE_XEXT */
/* #undef HAVE_XF86VM */
/* #undef HAVE_XINERAMA */
#define HAVE_NETPLAY 1
#define HAVE_NETWORK_CMD 1
#define HAVE_STDIN_CMD 1
#define HAVE_COMMAND 1
#define HAVE_SOCKET_LEGACY 1
/* #undef HAVE_FBO */
#define HAVE_STRL 1
/* #undef HAVE_PYTHON */
#define HAVE_BSV_MOVIE 1
/* #undef HAVE_VIDEOCORE */
/* #undef HAVE_NEON */
/* #undef HAVE_FLOATHARD */
/* #undef HAVE_FLOATSOFTFP */
#endif
