package org.andretro.system;

import android.util.Log;

public class Logger
{
	public static void d(String m)
	{
		Log.d("andretro", m);
	}
}
