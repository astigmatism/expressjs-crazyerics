package org.andretro.system;

public class PngWriter
{	
	public static boolean write(final String aFileName)
	{
		return false;
	}
}
